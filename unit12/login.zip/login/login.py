import datetime
import csv
import hashlib

"""
    This program demonstrates the ability to of a
    program to manage users' login information
    in a flat database file (i.e. a CSV file).
"""

def main ( ):
    """ Asks the user what they want to do and does it """
    menu = "1. Add new user\n2. Test log in\n3. Exit\n"
    choice = input ( menu + "Select an option: " )
    while ( choice[0] in ["1", "2"] ):
        if choice[0] == "1":
            add_user ()
        else:
            print ( login_user () )
        choice = input ( menu + "Select an option: " )
    print ( "Goodbye" )

def add_user ( ):
    """ Adds a user to the CSV file with a hashed password """
    # get the new user info
    username = input ( "Enter your username: " )
    password = input ( "Enter your new password: " )
    # this line hashes (encrpyts) the password
    hashed = hashlib.sha256( password.encode() ).hexdigest()
    date = str(datetime.datetime.now())

    # combines all three values into a list
    row = [ username, hashed, date ]

    # Task 1: add it to the data file using the csv writer
    

def login_user ( ):
    """ Test a login using a hashed password """
    # get the user info
    username = input ( "Enter your username: " )
    password = input ( "Enter your password: " )
    hashed = hashlib.sha256( password.encode() ).hexdigest()

    # Task 2: open the file and see check the login credentials
    # if they match return "Login successful" or if not then return
    # "Passwords do not match" otherwise "No such user"


    return "No such user"

# starts the program
main ()