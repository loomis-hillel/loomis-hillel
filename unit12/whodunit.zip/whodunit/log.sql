-- Include the list of queries you use to solve the mystery here.
-- Be sure to include a semicolon at the end of each query: like this ->;

SELECT *
FROM crime_scene_reports
WHERE year = 2020 AND month = 7 AND day = 28;
