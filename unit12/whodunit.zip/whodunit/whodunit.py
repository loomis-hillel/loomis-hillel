import cs50
import csv

db = cs50.SQL("sqlite:///whodunit.db")

def main ( ):
    """ Runs the queries located in the log.sql file and produces
        the output in several numbered files q1.out, q2out, etc. """
    with open ( "log.sql", "r" ) as query_file:
        queries = query_file.read().split(";")

    print ( "Running queries..." )
    for i in range ( 1, len(queries) ):
        filename = f"Q{i}.csv"
        query = queries[i].strip()
        if len(query) > 0:
            rows = db.execute( query )
            print ( f"{filename} <= {query}" )
            if len(rows) > 0:
                with open ( filename, "w" ) as result_file:
                    writer = csv.DictWriter( result_file, fieldnames=rows[0].keys() )
                    writer.writeheader()
                    for row in rows:
                        writer.writerow ( row )

main ()

