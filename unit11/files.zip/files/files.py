import datetime
"""
    This program demonstrates the ability to open several file
    for different purposes: reading, writing, and appending.
    It uses the datatime library to append a date/time to a file.
"""

print ( "Demonstrates the ability to read a text file: " )
with open("text.txt", "r") as my_file:
    contents = my_file.read( )
print ( contents )

print ( )

print ( "Demonstrates the ability to write a text file: " )
some_text = "Hello, it's me"
with open("text2.txt", "w") as my_file:
    my_file.write ( some_text + "\n" )
print ( "Open text2.txt to see the output" )

print ( )

print ( "Demonstrates the ability to append a data file: " )
username = input ( "Enter your username: " )
password = input ( "Enter your password: " )
date = datetime.datetime.now()
with open("users.csv", "a") as my_file:
    my_file.write ( f"{username},{password},{date}\n" )
print ( "Open users.csv to see the data added to the file" )

print ( )

with open("users.csv", "r") as my_file:
    contents = my_file.read( )
print ( contents )