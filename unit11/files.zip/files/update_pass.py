import datetime
import csv
"""
    This program demonstrates the ability to open a file
    and update a record in the file. In reality, it takes
    two steps. Opening the file and loading the data.
    Makin the chagnge in the data and saving the updates.
"""

print ( "Loads the CSV file: " )
with open("users.csv", "r") as csv_file:
    contents = list (csv.reader( csv_file ))
print ( contents )

print ( )

print ( "Demonstrates the ability to update the data: " )
username = input ( "Enter your username: " )
password = input ( "Enter your new password: " )
date = datetime.datetime.now()
for row in contents:
    if row[0] == username:
        row[1] = password
        row[2] = str(date)

with open("users.csv", "w") as csv_file:
    writer = csv.writer ( csv_file )
    for row in contents:
        writer.writerow ( row )
print ( "Open users.csv to see the data update in the file" )
